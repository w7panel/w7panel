import{_ as e}from"./__vite-browser-external.6972aaa0.js";import{aL as r}from"./arco.fe2d91f6.js";const o=r(e);export{o as r};
