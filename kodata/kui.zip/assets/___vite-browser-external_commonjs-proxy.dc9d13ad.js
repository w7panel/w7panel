import{_ as e}from"./__vite-browser-external.6972aaa0.js";import{aL as r}from"./arco.a7188e94.js";const o=r(e);export{o as r};
